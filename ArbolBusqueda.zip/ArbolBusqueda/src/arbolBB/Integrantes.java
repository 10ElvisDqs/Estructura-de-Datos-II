/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arbolBB;

/**
 *
 * @author Toloza XD
 */
public class Integrantes {
    
    /* Reyna Marinely Cerritos Cornejo CC16124
    Enrique Josué Cortez Hernández     CH14008
    Reynaldo Eliseo Diaz Molina        DM16015
    Roberto Alexander Toloza Mendoza   TM16010
    */
    
}
